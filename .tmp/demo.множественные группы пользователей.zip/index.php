<?
include_once($_SERVER['DOCUMENT_ROOT'] . '/k2/content.php');
?>