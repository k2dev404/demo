<?
header('Location: /k2/admin/dev/field/site/');
?>