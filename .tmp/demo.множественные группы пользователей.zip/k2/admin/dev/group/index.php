<?
header('Location: /k2/admin/fun/');
?>