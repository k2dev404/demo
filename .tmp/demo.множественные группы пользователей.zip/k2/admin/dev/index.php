<?
header('Location: block/');
?>