</td>
<td></td>
</tr>
<tr class="foot">
	<td class="copy">&copy; 2005-2016 <a href="http://www.k2cms.ru/">K2CMS</a></td>
	<td></td>
	<td class="b4"></td>
	<td></td>
</tr>
<tr class="b5">
	<td colspan="4"></td>
</tr>
</table>
</body>
</html>