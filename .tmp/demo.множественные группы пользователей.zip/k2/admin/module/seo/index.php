<?
header('Location: /k2/admin/module/seo/page/');
?>