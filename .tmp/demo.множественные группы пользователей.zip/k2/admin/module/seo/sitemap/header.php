<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="/k2/admin/css/style.css">
	<title>K2CMS</title>
	<style>
		html, body {
			background: #fff;
		}
	</style>
</head>
<body>