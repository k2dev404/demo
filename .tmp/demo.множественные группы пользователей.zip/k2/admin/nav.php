<?
$arNav['/message/'] = 'Сообщения';
$arNav['/dev/block/'] = 'Функциональные блоки';
$arNav['/dev/form/'] = 'Формы';
$arNav['/dev/design/'] = 'Макеты дизайна';
$arNav['/dev/nav/'] = 'Шаблоны навигации';
$arNav['/dev/email/'] = 'Шаблоны писем';
$arNav['/dev/field/'] = 'Поля';
$arNav['/dev/field/site/'] = 'Для сайта';
$arNav['/dev/field/section/'] = 'Для разделов';
$arNav['/dev/field/user/'] = 'Для пользователей';
?>