<?
global $URL;
?><div class="foot">
	<div class="footBox">
    	<div class="icon">
        	<a href="<?=$URL[29]?>" class="op"><img src="/i/icon/9.png"><span>Калькулятор<br>стоимости</span></a>
            <a href="<?=$URL[27]?>" class="op i2"><img src="/i/icon/10.png"><span>Подбор<br>окна</span></a>
            <a href="#" data-url="<?=$URL[28]?>?ajax=1" class="op i3 modal"><img src="/i/icon/11.png"><span>Вызвать<br>замерщика</span></a>
        </div>
    	<div class="bottomMenu">
            <a href="/">Главная</a>
            <a href="<?=$URL[18]?>">Услуги и сервис</a>
            <a href="<?=$URL[10]?>">Готовые решения</a>
            <a href="<?=$URL[23]?>">Акции</a>
            <a href="<?=$URL[25]?>">Дилерам</a>
            <a href="<?=$URL[12]?>">Окна REHAU</a>
            <a href="<?=$URL[4]?>">Продукция</a>
            <a href="<?=$URL[45]?>">Вакансии</a>
            <a href="<?=$URL[14]?>">Окна GOOGWIN</a>
            <?/*
            <a href="<?=$URL[13]?>">Окна LG HAUSYS</a>
            */?>
            <a href="<?=$URL[26]?>">Контакты</a>
            <a href="<?=$URL[24]?>">Производство</a>
        </div>
    </div>
    <div class="copy">
    	<div class="copyBox">&copy; Все права защищены 2010 — 2016. Пластиковые окна, пластиковые двери, рольворота от производителя. Ростов-на-Дону. <br><a href="http://it-don.ru">Продвижение и создание сайта</a> - IT-DON</div>
    </div>
</div>
<!-- Yandex.Metrika counter -->
<script type="text/javascript">
(function (d, w, c) {
    (w[c] = w[c] || []).push(function() {
        try {
            w.yaCounter26191422 = new Ya.Metrika({id:26191422,
                    webvisor:true,
                    clickmap:true,
                    trackLinks:true,
                    accurateTrackBounce:true});
        } catch(e) { }
    });

    var n = d.getElementsByTagName("script")[0],
        s = d.createElement("script"),
        f = function () { n.parentNode.insertBefore(s, n); };
    s.type = "text/javascript";
    s.async = true;
    s.src = (d.location.protocol == "https:" ? "https:" : "http:") + "//mc.yandex.ru/metrika/watch.js";

    if (w.opera == "[object Opera]") {
        d.addEventListener("DOMContentLoaded", f, false);
    } else { f(); }
})(document, window, "yandex_metrika_callbacks");
</script>
<noscript><div><img src="//mc.yandex.ru/watch/26191422" style="position:absolute; left:-9999px;" alt="" /></div></noscript>
<!-- /Yandex.Metrika counter -->
<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'Sk9vFLI7OC';
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);})();</script>
<!-- {/literal} END JIVOSITE CODE -->