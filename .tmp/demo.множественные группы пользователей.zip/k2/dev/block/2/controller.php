<?
$this->List = $LIB['SECTION']->Map(array('SITE' => $CURRENT['SITE']['ID'], 'ACTIVE' => 1));

$this->Template();
?>