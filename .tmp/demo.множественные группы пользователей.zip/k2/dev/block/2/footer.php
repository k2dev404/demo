                <div class="block4">
                	<div class="title">Офисы продаж</div>
                    <div class="block4Box">
                    	<div class="left">
                        	<div class="leftBlock">
                            	<a href="<?=$URL[26]?>#c1"><img src="i/map/1.jpg" width="553" height="80"></a>
                                <a href="<?=$URL[26]?>#c2"><img src="i/map/2.jpg" width="553" height="80"></a>
                                <a href="<?=$URL[26]?>#c3"><img src="i/map/3.jpg" width="553" height="80"></a>
                                <a href="<?=$URL[26]?>#c5"><img src="i/map/5.jpg" width="553" height="80"></a>
                                <a href="<?=$URL[26]?>#c4"><img src="i/map/4.jpg" width="553" height="80"></a>
                            </div>
                        </div>
                        <div class="right">
                        	<div class="rightBox">
<!--p>Оформить заявку на замер или купить пластиковые окна весьма просто - обратитесь в один из офисов продаж компании «Спектр» Ростова-на-Дону, Азова, Кулешовки, Батайска, Таганрога и Ейска.</p-->
<p>Оформить заявку на замер или купить пластиковые окна весьма просто - обратитесь в один из офисов продаж компании «Спектр» Ростова-на-Дону, Азова, Кулешовки, Батайска, Таганрога и Ейска, контакты которых вы можете найти <a href="/kontakti/">здесь</a>.</p>
<p>По вопросам сотрудничества обращайтесь в дилерский отдел завода по телефону<br>(86342) 66-7-99, 8-988-563-67-77.</p>
<!--p>Ростовская область, г. Азов, ул. Победы, 25</p-->
                          		<?/*
                          		<p>Для наиболее эффективного сотрудничества<br>с дилерами и строительными организациями, нашей компанией предоставляется пакет услуг, включающий в себя:</p>
                                <div class="prop">
                                	<div class="item">
                                    	<img src="i/icon/4.png" alt="" class="m">
                                        Полная комплектация со складов ЗМК «Спектр», а также доставка готовой продукции (при необходимости замер и установка изделий)
                                    </div>
                                    <div class="item">
                                    	<img src="i/icon/5.png" alt="">
                                        Гибкая ценовая политика
                                    </div>
                                    <div class="item">
                                    	<img src="i/icon/6.png" alt="">
                                        Бесплатные консультации
                                    </div>
                                    <div class="item">
                                    	<img src="i/icon/7.png" alt="" class="m">
                                        Обеспечение программными продуктами и технической поддержкой
                                    </div>
                                    <div class="item">
                                    	<img src="i/icon/8.png" alt="" class="m">
                                        Оснащение проспектами<br>и презентационными материалами
                                    </div>
                                </div>
                                */?>
                            </div>
                        </div>
                        <div class="clear"></div>
                    </div>
                </div>
                <div class="block5">
                	<a href="#" data-url="<?=$URL[32]?>?ajax=1" class="modal">
                    	<img src="/i/photo/3.jpg" width="300" height="182" alt="">
                        <span class="name">Трудно выбрать окно?</span>
                        <span class="text">Задайте вопрос технологу</span>
                    </a>
                    <a href="#" data-url="<?=$URL[31]?>?ajax=1" class="modal">
                    	<img src="/i/photo/4.jpg" width="300" height="182" alt="">
                        <span class="name">Заказать звонок</span>
                        <span class="text">И мы вам перезвоним в удобное для вас время</span>
                    </a>
                    <a href="#" data-url="<?=$URL[28]?>?ajax=1" class="modal">
                    	<img src="/i/photo/5.jpg" width="300" height="182" alt="">
                        <span class="name">Записаться на замер</span>
                        <span class="text">Замерщик быстро и точно оценит стоимость окон</span>
                    </a>
                    <div class="clear"></div>
                </div>
                
                <div id="perelink">
                	<p>Группа компаний СПЕКТР</p>
                	<div class="links">
						<a href="http://spektr-plast.ru" target="_blank"><img src="/i/logo-spektrplast.png"></a>
						<a href="http://spektr-pack.ru" target="_blank"><img src="/i/logospektrpak.png"></a>
					</div>	
                    <div class="clear"></div>
                </div>
                
            </div>
            <?include_once($_SERVER['DOCUMENT_ROOT'].'/k2/dev/design/1/footer.php')?>
        </div>
	</body>
</html>