                    </div>
                    <div class="clear"></div>
                </div>
                <div class="block5">
                	<a href="#" data-url="<?=$URL[32]?>?ajax=1" class="modal">
                    	<img src="/i/photo/3.jpg" width="300" height="182" alt="">
                        <span class="name">Трудно выбрать окно?</span>
                        <span class="text">Задайте вопрос технологу</span>
                    </a>
                    <a href="#" data-url="<?=$URL[31]?>?ajax=1" class="modal">
                    	<img src="/i/photo/4.jpg" width="300" height="182" alt="">
                        <span class="name">Заказать звонок</span>
                        <span class="text">И мы вам перезвоним в удобное для вас время</span>
                    </a>
                    <a href="#" data-url="<?=$URL[28]?>?ajax=1" class="modal">
                    	<img src="/i/photo/5.jpg" width="300" height="182" alt="">
                        <span class="name">Записаться на замер</span>
                        <span class="text">Замерщик быстро и точно оценит стоимость окон</span>
                    </a>
                    <div class="clear"></div>
                </div>
                
                <div id="perelink">
                	<p>Группа компаний СПЕКТР</p>
                	<div class="links">
						<a href="http://spektr-plast.ru" target="_blank"><img src="/i/logo-spektrplast.png"></a>
						<a href="http://spektr-pack.ru" target="_blank"><img src="/i/logospektrpak.png"></a>
					</div>	
                    <div class="clear"></div>
                </div>
                
            </div>
            <? include_once($_SERVER['DOCUMENT_ROOT'].'/k2/dev/design/1/footer.php'); ?>
        </div>
	</body>
</html>