</div>
</div>
</div>
<div class="foot">
	<div class="box">
		<?$LIB['NAV']->Menu(3, array('ACTIVE' => 1))?>
		<div class="copy">Компания «ТеплоМак»<br>© 2016</div>
		<div class="dev"><a href="http://www.it-don.ru"><img src="i/itdon.png" alt="" align="right"></a> Разработка<br>сайта</div>
	</div>
</div>
</div>
</body>
</html>