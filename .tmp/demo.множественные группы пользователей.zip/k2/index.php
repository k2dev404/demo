<?
header('Location: /k2/admin/section/');
?>