<?
$MESS['THIS_GROUP_ALREADY_EXISTS'] = 'Такая группа уже существует';
$MESS['GROUP_NOT_FOUND'] = 'Группа не найдена';
$MESS['CAN_NOT_BE_REMOVED_GROUP'] = 'Удаление невозможно. Сперва удалите все блоки из этой группы';
$MESS['BLOCK_NOT_FOUND'] = 'Блок не найден';
?>
