<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/db/class.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/db/class.query_builder.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/db/function.php');

$DB = $LIB['DB'] = new DB();
?>