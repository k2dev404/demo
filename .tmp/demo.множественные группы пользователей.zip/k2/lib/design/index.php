<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/design/class.php');
$LIB['DESIGN'] = new Design();
?>