<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/email/class.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/email/class.phpmailer.php');
$LIB['EMAIL'] = new Email();
?>