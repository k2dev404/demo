<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/event/class.php');
$LIB['EVENT'] = new Event();
?>