<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/field/class.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/field/class.separator.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/field/function.php');
$LIB['FIELD'] = new Field();
$LIB['FIELD_SEPARATOR'] = new FieldSeparator();
?>