<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/file/lang/ru.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/file/class.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/file/class.dir.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/file/function.php');
$LIB['FILE'] = new File();
$LIB['FILE_DIR'] = new FileDir();
?>