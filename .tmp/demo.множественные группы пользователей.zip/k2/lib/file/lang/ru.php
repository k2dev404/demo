<?
$MESS['FILE_CREATED_DIR'] = 'Не удалось создать папку %FIELD%';
$MESS['FILE_CREATED_FILE'] = 'Не удалось создать файл %FIELD%';
$MESS['FILE_EXISTS'] = 'Файла не существует %FIELD%';
$MESS['FILE_READABLE'] = 'Не удалось прочитать файл %FIELD%';
$MESS['FILE_WRITE'] = 'Не удалось переписать файл %FIELD%';
$MESS['FILE_DELETE_DIR'] = 'Не удалось удалить папку %FIELD%';
$MESS['FILE_DELETE_FILE'] = 'Не удалось удалить файл %FIELD%';
?>