<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/form/lang/ru.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/form/class.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/form/class.message.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/form/function.php');
$LIB['FORM'] = new Form();
$LIB['FORM_MESSAGE'] = new FormMessage();
?>