<?
$MESS['FORM_EMPTY_FIELD'] = 'Заполните поле "%FIELD%"';
?>
