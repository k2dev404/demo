<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/module/class.php');
$LIB['MODULE'] = new Module();
?>