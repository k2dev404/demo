<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/nav/class.php');
$LIB['NAV'] = new Nav();
?>