<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/photo/class.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/photo/class.gd.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/photo/class.im.php');
$LIB['PHOTO'] = new Photo();
?>