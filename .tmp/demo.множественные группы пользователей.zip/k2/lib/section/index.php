<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/section/class.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/section/class.block.php');
$LIB['SECTION'] = new Section();
$LIB['SECTION_BLOCK'] = new SectionBlock();
?>