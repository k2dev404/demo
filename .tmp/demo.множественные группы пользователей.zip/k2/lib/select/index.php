<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/select/class.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/select/class.option.php');
$LIB['SELECT'] = new Select();
$LIB['SELECT_OPTION'] = new SelectOption();
?>