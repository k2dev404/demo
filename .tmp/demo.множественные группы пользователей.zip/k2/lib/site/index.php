<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/site/class.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/site/function.php');
$LIB['SITE'] = new Site();
?>