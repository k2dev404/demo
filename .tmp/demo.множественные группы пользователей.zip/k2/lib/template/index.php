<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/template/class.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/template/function.php');
$LIB['TEMPLATE'] = new Template();
?>