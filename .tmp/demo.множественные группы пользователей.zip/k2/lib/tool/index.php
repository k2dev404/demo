<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/tool/class.php');
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/tool/function.php');
?>