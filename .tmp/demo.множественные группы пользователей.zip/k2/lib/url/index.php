<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/lib/url/class.php');
$LIB['URL'] = new URL();
?>