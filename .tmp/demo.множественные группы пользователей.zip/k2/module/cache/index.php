<?
require_once($_SERVER['DOCUMENT_ROOT'].'/k2/module/cache/class.php');
$MOD['CACHE'] = new Cache();
?>