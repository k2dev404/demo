<?
class Shop
{

}
?>